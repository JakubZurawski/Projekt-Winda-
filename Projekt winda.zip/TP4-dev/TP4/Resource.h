﻿//{{NO_DEPENDENCIES}}
// Plik dołączany wygenerowany przez program Microsoft Visual C++.
// Używane przez: TP4.rc

#define IDS_APP_TITLE			103

#define IDR_MAINFRAME			128
#define IDD_TP4_DIALOG	102
#define IDD_ABOUTBOX			103
#define IDM_ABOUT				104
#define IDM_EXIT				105
#define IDI_TP4			107
#define IDI_SMALL				108
#define IDC_TP4			109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1


#define ID_BUTTON01				5
#define ID_BUTTON02				1
#define ID_BUTTON03				3
#define ID_BUTTON04				4


#define ID_BUTTON10				6
#define ID_BUTTON12				7
#define ID_BUTTON13				8		
#define ID_BUTTON14				9

#define ID_BUTTON20				10
#define ID_BUTTON21				11
#define ID_BUTTON23				12		
#define ID_BUTTON24				13



#define ID_BUTTON30				14
#define ID_BUTTON31				15
#define ID_BUTTON32				16		
#define ID_BUTTON34				17


#define ID_BUTTON40				18
#define ID_BUTTON41				19
#define ID_BUTTON42				20		
#define ID_BUTTON43				21

#define ID_TIMER1				1


#endif
// Następne wartości domyślne dla nowych obiektów
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
